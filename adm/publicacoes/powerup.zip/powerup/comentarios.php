 <!-- /.post-navigation -->
                                <div id="comments" class="comments-area">
                                    <h2 class="comments-title"> 3 Comment</h2>
                                    <ol class="commentlist">
                                        <li class="comment byuser comment-author-admin bypostauthor even thread-even depth-1">
                                            <div class="comment_container">
                                                <img width="100" height="100" class="avatar avatar-100 photo" src="assets/images/blog/author.jpg" alt="">
                                                <div class="comment-text">
                                                    <div class="meta">
                                                        <strong class="woocommerce-review__author" itemprop="author">Jane Smith</strong>
                                                        <time datetime="2017-03-23T08:06:09+00:00" class="woocommerce-review__published-date">July 24, 2017</time>
                                                    </div>
                                                    <div class="comment-content">
                                                        <div class="description">
                                                            <p>good</p>
                                                        </div>
                                                        <div class="reply">
                                                            <a class="comment-edit-link" href="#">Edit</a>
                                                            <a href="#respond" class="comment-reply-link" rel="nofollow">Reply</a>
                                                        </div>
                                                        <!-- .reply -->
                                                    </div>
                                                    <!-- .comment-content -->
                                                </div>
                                                <!-- .comment-text -->
                                            </div>
                                            <!-- .comment_container -->
                                        </li>
                                        <!-- .comment -->
                                        <li class="comment byuser comment-author-admin bypostauthor even thread-even depth-1">
                                            <div class="comment_container">
                                                <img width="100" height="100" class="avatar avatar-100 photo" src="assets/images/blog/author.jpg" alt="">
                                                <div class="comment-text">
                                                    <div class="meta">
                                                        <strong class="woocommerce-review__author" itemprop="author">Jane Smith</strong>
                                                        <time datetime="2017-03-23T08:06:09+00:00" class="woocommerce-review__published-date">July 24, 2017</time>
                                                    </div>
                                                    <div class="comment-content">
                                                        <div class="description">
                                                            <p>Awesome</p>
                                                        </div>
                                                        <div class="reply">
                                                            <a class="comment-edit-link" href="#">Edit</a>
                                                            <a href="#respond" class="comment-reply-link" rel="nofollow">Reply</a>
                                                        </div>
                                                        <!-- .reply -->
                                                    </div>
                                                    <!-- .comment-content -->
                                                </div>
                                                <!-- .comment-text -->
                                            </div>
                                            <!-- .comment_container -->
                                        </li>
                                        <!-- .comment -->
                                        <li class="comment byuser comment-author-admin bypostauthor even thread-even depth-1">
                                            <div class="comment_container">
                                                <img width="100" height="100" class="avatar avatar-100 photo" src="assets/images/blog/author.jpg" alt="">
                                                <div class="comment-text">
                                                    <div class="meta">
                                                        <strong class="woocommerce-review__author" itemprop="author">Jane Smith</strong>
                                                        <time datetime="2017-03-23T08:06:09+00:00" class="woocommerce-review__published-date">July 24, 2017</time>
                                                    </div>
                                                    <div class="comment-content">
                                                        <div class="description">
                                                            <p>Nice</p>
                                                        </div>
                                                        <div class="reply">
                                                            <a class="comment-edit-link" href="#">Edit</a>
                                                            <a href="#respond" class="comment-reply-link" rel="nofollow">Reply</a>
                                                        </div>
                                                        <!-- .reply -->
                                                    </div>
                                                    <!-- .comment-content -->
                                                </div>
                                                <!-- .comment-text -->
                                            </div>
                                            <!-- .comment_container -->
                                        </li>
                                        <!-- .comment -->
                                    </ol>
                                    <!-- .commentlist -->