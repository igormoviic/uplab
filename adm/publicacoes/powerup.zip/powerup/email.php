 <footer class="site-footer ">
    <div class="col-full">
        <div class="before-footer-wrap">
            <div class="col-full">
                <div class="footer-newsletter">
                    <div class="media">
                        <i class="footer-newsletter-icon tm tm-newsletter"></i>
                        <div class="media-body">
                            <div class="clearfix">
                                <!-- .newsletter-header -->
                                <div class="newsletter-body">
                                    <form class="newsletter-form">
                                        <input type="text" placeholder="INSCREVA-SE E MUDE DE NÍVEL">
                                        <button class="button" type="button">BAIXAR EBOOK</button>
                                    </form>
                                </div>
                                <!-- .newsletter body -->
                            </div>
                            <!-- .clearfix -->
                        </div>
                        <!-- .media-body -->
                    </div>
                    <!-- .media -->
                </div>
                <!-- .footer-newsletter -->
                <div class="footer-social-icons">
                    <ul class="social-icons nav">
                        <li class="nav-item">
                            <a class="sm-icon-label-link nav-link" href="#">
                                <i class="fa fa-facebook"></i> Facebook</a>
                            </li>
                            <li class="nav-item">
                                <a class="sm-icon-label-link nav-link" href="#">
                                    <i class="fa fa-instagram"></i> Instagram</a>
                                </li>
                                <li class="nav-item">
                                    <a class="sm-icon-label-link nav-link" href="#">
                                        <i class="fa fa-youtube"></i> YouTube</a>
                                    </li>
                                    
                                </ul>
                            </div>
                            <!-- .footer-social-icons -->
                        </div>
                        <!-- .col-full -->
                    </div>
                </div>
            </footer>
