<div class="widget techmarket_posts_carousel_widget">
    <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
    <script>
      (adsbygoogle = window.adsbygoogle || []).push({
        google_ad_client: "ca-pub-3684018647422676",
        enable_page_level_ads: true
    });
</script>
</div>