<?php

include('banner.php');
include('email.php');
include('blog.php');

?>